sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History"
], function(BaseController, MessageBox, Utilities, History) {
	"use strict";

	return BaseController.extend("com.sap.build.standard.desafioHomeOffice.controller.Questoes", {
		handleRouteMatched: function(oEvent) {
			var sAppId = "App5e0e3155cf5bb2780c3d3c58";

			var oParams = {};

			if (oEvent.mParameters.data.context) {
				this.sContext = oEvent.mParameters.data.context;

			} else {
				if (this.getOwnerComponent().getComponentData()) {
					var patternConvert = function(oParam) {
						if (Object.keys(oParam).length !== 0) {
							for (var prop in oParam) {
								if (prop !== "sourcePrototype" && prop.includes("Set")) {
									return prop + "(" + oParam[prop][0] + ")";
								}
							}
						}
					};

					this.sContext = patternConvert(this.getOwnerComponent().getComponentData().startupParameters);

				}
			}

			var oPath;

			if (this.sContext) {
				oPath = {
					path: "/" + this.sContext,
					parameters: oParams
				};
				this.getView().bindObject(oPath);
			}

		},
		_onPageNavButtonPress: function(oEvent) {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Menu", {
				externalCode: this.value
			});

		},
		doNavigate: function(sRouteName, oBindingContext, fnPromiseResolve, sViaRelation) {
			var sPath = (oBindingContext) ? oBindingContext.getPath() : null;
			var oModel = (oBindingContext) ? oBindingContext.getModel() : null;

			var sEntityNameSet;
			if (sPath !== null && sPath !== "") {
				if (sPath.substring(0, 1) === "/") {
					sPath = sPath.substring(1);
				}
				sEntityNameSet = sPath.split("(")[0];
			}
			var sNavigationPropertyName;
			var sMasterContext = this.sMasterContext ? this.sMasterContext : sPath;

			if (sEntityNameSet !== null) {
				sNavigationPropertyName = sViaRelation || this.getOwnerComponent().getNavigationPropertyForNavigationWithContext(sEntityNameSet, sRouteName);
			}
			if (sNavigationPropertyName !== null && sNavigationPropertyName !== undefined) {
				if (sNavigationPropertyName === "") {
					this.oRouter.navTo(sRouteName, {
						context: sPath,
						masterContext: sMasterContext
					}, false);
				} else {
					oModel.createBindingContext(sNavigationPropertyName, oBindingContext, null, function(bindingContext) {
						if (bindingContext) {
							sPath = bindingContext.getPath();
							if (sPath.substring(0, 1) === "/") {
								sPath = sPath.substring(1);
							}
						} else {
							sPath = "undefined";
						}

						// If the navigation is a 1-n, sPath would be "undefined" as this is not supported in Build
						if (sPath === "undefined") {
							this.oRouter.navTo(sRouteName);
						} else {
							this.oRouter.navTo(sRouteName, {
								context: sPath,
								masterContext: sMasterContext
							}, false);
						}
					}.bind(this));
				}
			} else {
				this.oRouter.navTo(sRouteName);
			}

			if (typeof fnPromiseResolve === "function") {
				fnPromiseResolve();
			}

		},
		avatarInitialsFormatter: function(sTextValue) {
			return typeof sTextValue === 'string' ? sTextValue.substr(0, 2) : undefined;

		},
		_onButtonPress: function() {
			
			var res1, res2, res3;
			res1 = res2 = res3 = null;
			
			for(var i = 0; i < 6; i++){
				if(this.botoes1[i].getPressed() == true){
					res1 = i;
				}
			}
			
			for(i = 0; i < 6; i++){
				if(this.botoes2[i].getPressed() == true){
					res2 = i;
				}
			}
			
			for(i = 0; i < 6; i++){
				if(this.botoes3[i].getPressed() == true){
					res3 = i;
				}
			}
			
			if(res1 === null || res2 === null || res3 === null){
				MessageBox.show("É necessário selecionar uma resposta para cada pergunta");
				return;
			}
			var test = false;
			$.ajax({
				"url": "/odata/v2/cust_DesafioHomeOfficeG4",
				"method": "POST",
				"timeout": 0,
				async: false,
				"headers": {
					"Authorization": "Basic c2ZhZG1pbkBTRlBBUlQwMzQ2NTc6cGFydDE4MDJEQzI=",
					"Content-Type": "application/json"
				},
				"data": JSON.stringify({
					"externalCode": this.value,
					"externalName": this.getView().byId("firstName").getText() + " " + this.getView().byId("lastName").getText(),
					"cust_nome": this.getView().byId("firstName").getText(),
					"cust_sobrenome": this.getView().byId("lastName").getText(),
					"cust_resposta1": res1,
					"cust_resposta2": res2,
					"cust_resposta3": res3
				}),
				success: function(data){
					test = true;
				},
				error: function(data){
					MessageBox.show("Erro ao enviar");
				}
			});
			if(test){
				var sTargetPos = "";
				sTargetPos = (sTargetPos === "default") ? undefined : sTargetPos;
				sap.m.MessageToast.show("Resposta enviada com sucesso!", {
					duration: 5000 || 3000,
					at: sTargetPos,
					my: sTargetPos
				});
			}
		},
		_onRouteMatched: function(oEvent){
			var oArgs, oView;
			oArgs = oEvent.getParameters("arguments");
			oView = this.getView();
			this.value = oArgs["arguments"]["externalCode"];
			console.log(oArgs["arguments"]);
			oView.bindElement({
				path : "/User('" + oArgs["arguments"]["externalCode"] + "')",
				events : {
			    dataRequested: function () {
		    		oView.setBusy(true);
		    	},
		    	dataReceived: function () {
		    		oView.setBusy(false);
		    	}
			}
		  });
		},
		setBut1: function (oEvent) {
			for(var i = 0; i < 6; i++){
				this.botoes1[i].setPressed(false);
			}
			for(i = 0; i < 6; i++){
				if(this.botoes1[i] == oEvent.getSource()){
					this.botoes1[i].setPressed(true);
				}
			}
		},
		
		setBut2: function (oEvent) {
			for(var i = 0; i < 6; i++){
				this.botoes2[i].setPressed(false);
			}
			for(i = 0; i < 6; i++){
				if(this.botoes2[i] == oEvent.getSource()){
					this.botoes2[i].setPressed(true);
				}
			}
		},
		
		setBut3: function (oEvent) {
			for(var i = 0; i < 6; i++){
				this.botoes3[i].setPressed(false);
			}
			for(i = 0; i < 6; i++){
				if(this.botoes3[i] == oEvent.getSource()){
					this.botoes3[i].setPressed(true);
				}
			}
		},
		
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Questoes").attachMatched(this._onRouteMatched, this);
			this.value = null;
			this.botoes1 = {
				0: this.getView().byId("radiante1"),
				1: this.getView().byId("muito1"),
				2: this.getView().byId("feliz1"),
				3: this.getView().byId("inseguro1"),
				4: this.getView().byId("triste1"),
				5: this.getView().byId("raivoso1")
			};
			
			this.botoes2 = {
				0: this.getView().byId("radiante2"),
				1: this.getView().byId("muito2"),
				2: this.getView().byId("feliz2"),
				3: this.getView().byId("inseguro2"),
				4: this.getView().byId("triste2"),
				5: this.getView().byId("raivoso2")
			};
			
			this.botoes3 = {
				0: this.getView().byId("radiante3"),
				1: this.getView().byId("muito3"),
				2: this.getView().byId("feliz3"),
				3: this.getView().byId("inseguro3"),
				4: this.getView().byId("triste3"),
				5: this.getView().byId("raivoso3")
			};

		}
	});
}, /* bExport= */ true);
