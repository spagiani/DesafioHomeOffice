sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History"
], function(BaseController, MessageBox, Utilities, History) {
	"use strict";

	return BaseController.extend("com.sap.build.standard.desafioHomeOffice.controller.Resultado", {
		handleRouteMatched: function(oEvent) {
			var sAppId = "App5e0e3155cf5bb2780c3d3c58";

			var oParams = {};

			if (oEvent.mParameters.data.context) {
				this.sContext = oEvent.mParameters.data.context;

			} else {
				if (this.getOwnerComponent().getComponentData()) {
					var patternConvert = function(oParam) {
						if (Object.keys(oParam).length !== 0) {
							for (var prop in oParam) {
								if (prop !== "sourcePrototype" && prop.includes("Set")) {
									return prop + "(" + oParam[prop][0] + ")";
								}
							}
						}
					};

					this.sContext = patternConvert(this.getOwnerComponent().getComponentData().startupParameters);

				}
			}

			var oPath;

			if (this.sContext) {
				oPath = {
					path: "/" + this.sContext,
					parameters: oParams
				};
				this.getView().bindObject(oPath);
			}

		},
		_onPageNavButtonPress: function(oEvent) {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Menu", {
				externalCode: this.value
			});

		},
		doNavigate: function(sRouteName, oBindingContext, fnPromiseResolve, sViaRelation) {
			var sPath = (oBindingContext) ? oBindingContext.getPath() : null;
			var oModel = (oBindingContext) ? oBindingContext.getModel() : null;

			var sEntityNameSet;
			if (sPath !== null && sPath !== "") {
				if (sPath.substring(0, 1) === "/") {
					sPath = sPath.substring(1);
				}
				sEntityNameSet = sPath.split("(")[0];
			}
			var sNavigationPropertyName;
			var sMasterContext = this.sMasterContext ? this.sMasterContext : sPath;

			if (sEntityNameSet !== null) {
				sNavigationPropertyName = sViaRelation || this.getOwnerComponent().getNavigationPropertyForNavigationWithContext(sEntityNameSet, sRouteName);
			}
			if (sNavigationPropertyName !== null && sNavigationPropertyName !== undefined) {
				if (sNavigationPropertyName === "") {
					this.oRouter.navTo(sRouteName, {
						context: sPath,
						masterContext: sMasterContext
					}, false);
				} else {
					oModel.createBindingContext(sNavigationPropertyName, oBindingContext, null, function(bindingContext) {
						if (bindingContext) {
							sPath = bindingContext.getPath();
							if (sPath.substring(0, 1) === "/") {
								sPath = sPath.substring(1);
							}
						} else {
							sPath = "undefined";
						}

						// If the navigation is a 1-n, sPath would be "undefined" as this is not supported in Build
						if (sPath === "undefined") {
							this.oRouter.navTo(sRouteName);
						} else {
							this.oRouter.navTo(sRouteName, {
								context: sPath,
								masterContext: sMasterContext
							}, false);
						}
					}.bind(this));
				}
			} else {
				this.oRouter.navTo(sRouteName);
			}

			if (typeof fnPromiseResolve === "function") {
				fnPromiseResolve();
			}

		},
		applyFiltersAndSorters: function(sControlId, sAggregationName, chartBindingInfo) {
			if (chartBindingInfo) {
				var oBindingInfo = chartBindingInfo;
			} else {
				var oBindingInfo = this.getView().byId(sControlId).getBindingInfo(sAggregationName);
			}
			var oBindingOptions = this.updateBindingOptions(sControlId);
			this.getView().byId(sControlId).bindAggregation(sAggregationName, {
				model: oBindingInfo.model,
				path: oBindingInfo.path,
				parameters: oBindingInfo.parameters,
				template: oBindingInfo.template,
				templateShareable: true,
				sorter: oBindingOptions.sorters,
				filters: oBindingOptions.filters
			});

		},
		updateBindingOptions: function(sCollectionId, oBindingData, sSourceId) {
			this.mBindingOptions = this.mBindingOptions || {};
			this.mBindingOptions[sCollectionId] = this.mBindingOptions[sCollectionId] || {};

			var aSorters = this.mBindingOptions[sCollectionId].sorters;
			var aGroupby = this.mBindingOptions[sCollectionId].groupby;

			// If there is no oBindingData parameter, we just need the processed filters and sorters from this function
			if (oBindingData) {
				if (oBindingData.sorters) {
					aSorters = oBindingData.sorters;
				}
				if (oBindingData.groupby || oBindingData.groupby === null) {
					aGroupby = oBindingData.groupby;
				}
				// 1) Update the filters map for the given collection and source
				this.mBindingOptions[sCollectionId].sorters = aSorters;
				this.mBindingOptions[sCollectionId].groupby = aGroupby;
				this.mBindingOptions[sCollectionId].filters = this.mBindingOptions[sCollectionId].filters || {};
				this.mBindingOptions[sCollectionId].filters[sSourceId] = oBindingData.filters || [];
			}

			// 2) Reapply all the filters and sorters
			var aFilters = [];
			for (var key in this.mBindingOptions[sCollectionId].filters) {
				aFilters = aFilters.concat(this.mBindingOptions[sCollectionId].filters[key]);
			}

			// Add the groupby first in the sorters array
			if (aGroupby) {
				aSorters = aSorters ? aGroupby.concat(aSorters) : aGroupby;
			}

			var aFinalFilters = aFilters.length > 0 ? [new sap.ui.model.Filter(aFilters, true)] : undefined;
			return {
				filters: aFinalFilters,
				sorters: aSorters
			};

		},
		_onRouteMatched: function(oEvent){
			var oArgs, oView;
			oArgs = oEvent.getParameters("arguments");
			oView = this.getView();
			this.value = oArgs["arguments"]["externalCode"];
			console.log(oArgs["arguments"]);
			oView.bindElement({
				path : "/User('" + oArgs["arguments"]["externalCode"] + "')",
				events : {
			    dataRequested: function () {
		    		oView.setBusy(true);
		    	},
		    	dataReceived: function () {
		    		oView.setBusy(false);
		    	}
			}
		  });
		},
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Resultado").attachMatched(this._onRouteMatched, this);

			var oView = this.getView(),
				oData = {},
				self = this;
			var oModel = new sap.ui.model.json.JSONModel();
			oView.setModel(oModel, "staticDataModel");
			self.oBindingParameters = {};

			oData["sap_m_Page_0-content-sap_chart_BarChart-1578318220486"] = {};

			oData["sap_m_Page_0-content-sap_chart_BarChart-1578318220486"]["data"] = [{
				"dim0": "Radiante",
				"mea0": "0",
				"__id": 0
			}, {
				"dim0": "Muito Feliz",
				"mea0": "0",
				"__id": 1
			}, {
				"dim0": "Feliz",
				"mea0": "0",
				"__id": 2
			}, {
				"dim0": "Inseguro",
				"mea0": "0",
				"__id": 3
			}, {
				"dim0": "Triste",
				"mea0": "0",
				"__id": 4
			}, {
				"dim0": "Raivoso",
				"mea0": "0",
				"__id": 5
			}];

			self.oBindingParameters['sap_m_Page_0-content-sap_chart_BarChart-1578318220486'] = {
				"path": "/sap_m_Page_0-content-sap_chart_BarChart-1578318220486/data",
				"model": "staticDataModel",
				"parameters": {}
			};

			oData["sap_m_Page_0-content-sap_chart_BarChart-1578318220486"]["vizProperties"] = {
				"plotArea": {
					"dataLabel": {
						"visible": true,
						"hideWhenOverlap": true
					}
				}
			};

			oData["sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-5-content-sap_chart_BarChart-1578318543748"] = {};

			oData["sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-5-content-sap_chart_BarChart-1578318543748"]["data"] = [{
				"dim0": "Radiante",
				"mea0": "0",
				"__id": 0
			}, {
				"dim0": "Muito Feliz",
				"mea0": "0",
				"__id": 1
			}, {
				"dim0": "Feliz",
				"mea0": "0",
				"__id": 2
			}, {
				"dim0": "Inseguro",
				"mea0": "0",
				"__id": 3
			}, {
				"dim0": "Triste",
				"mea0": "0",
				"__id": 4
			}, {
				"dim0": "Raivoso",
				"mea0": "0",
				"__id": 5
			}];

			self.oBindingParameters['sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-5-content-sap_chart_BarChart-1578318543748'] = {
				"path": "/sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-5-content-sap_chart_BarChart-1578318543748/data",
				"model": "staticDataModel",
				"parameters": {}
			};

			oData["sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-5-content-sap_chart_BarChart-1578318543748"]["vizProperties"] = {
				"plotArea": {
					"dataLabel": {
						"visible": true,
						"hideWhenOverlap": true
					}
				}
			};

			oData["sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-1578317867784-content-sap_chart_BarChart-1578318553585"] = {};

			oData["sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-1578317867784-content-sap_chart_BarChart-1578318553585"]["data"] = [{
				"dim0": "Radiante",
				"mea0": "0",
				"__id": 0
			}, {
				"dim0": "Muito Feliz",
				"mea0": "0",
				"__id": 1
			}, {
				"dim0": "Feliz",
				"mea0": "0",
				"__id": 2
			}, {
				"dim0": "Inseguro",
				"mea0": "0",
				"__id": 3
			}, {
				"dim0": "Triste",
				"mea0": "0",
				"__id": 4
			}, {
				"dim0": "Raivoso",
				"mea0": "0",
				"__id": 5
			}];

			self.oBindingParameters['sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-1578317867784-content-sap_chart_BarChart-1578318553585'] = {
				"path": "/sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-1578317867784-content-sap_chart_BarChart-1578318553585/data",
				"model": "staticDataModel",
				"parameters": {}
			};

			oData["sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-1578317867784-content-sap_chart_BarChart-1578318553585"]["vizProperties"] = {
				"plotArea": {
					"dataLabel": {
						"visible": true,
						"hideWhenOverlap": true
					}
				}
			};

			oView.getModel("staticDataModel").setData(oData, true);

			function dateDimensionFormatter(oDimensionValue, sTextValue) {
				var oValueToFormat = sTextValue !== undefined ? sTextValue : oDimensionValue;
				if (oValueToFormat instanceof Date) {
					var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
						style: "short"
					});
					return oFormat.format(oValueToFormat);
				}
				return oValueToFormat;
			}

			var aDimensions = oView.byId("sap_m_Page_0-content-sap_chart_BarChart-1578318220486").getDimensions();
			aDimensions.forEach(function(oDimension) {
				oDimension.setTextFormatter(dateDimensionFormatter);
			});

			var aDimensions = oView.byId("sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-5-content-sap_chart_BarChart-1578318543748").getDimensions();
			aDimensions.forEach(function(oDimension) {
				oDimension.setTextFormatter(dateDimensionFormatter);
			});

			var aDimensions = oView.byId("sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-1578317867784-content-sap_chart_BarChart-1578318553585").getDimensions();
			aDimensions.forEach(function(oDimension) {
				oDimension.setTextFormatter(dateDimensionFormatter);
			});

		},
		onAfterRendering: function() {

			var oChart,
				self = this,
				oBindingParameters = this.oBindingParameters,
				oView = this.getView();

			oChart = oView.byId("sap_m_Page_0-content-sap_chart_BarChart-1578318220486");
			oChart.bindData(oBindingParameters['sap_m_Page_0-content-sap_chart_BarChart-1578318220486']);

			oChart = oView.byId("sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-5-content-sap_chart_BarChart-1578318543748");
			oChart.bindData(oBindingParameters['sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-5-content-sap_chart_BarChart-1578318543748']);

			oChart = oView.byId("sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-1578317867784-content-sap_chart_BarChart-1578318553585");
			oChart.bindData(oBindingParameters['sap_m_Page_0-content-sap_m_IconTabBar-1578317620752-items-sap_m_IconTabFilter-1578317867784-content-sap_chart_BarChart-1578318553585']);

		}
	});
}, /* bExport= */ true);
